# CoinList React SDK

React components and client/server helpers for integrating CoinList OAuth (PKCE) into your app. This guide assumes a **Next.js (App Router) + React** setup.

```bash
npm install @coinlist-co/react
```

## Styling

Pre-built UI components (e.g. `CoinListSignInCard`) **automatically include their styles** when you import from `@coinlist-co/react/client/components`.

If you prefer explicit control, you can also import the SDK stylesheet once:

```ts
import '@coinlist-co/react/styles.css';
```

## Overview

| Piece | Role |
|-------|------|
| **`CoinListClient`** (`createCoinListClient`) | Browser-only: starts OAuth redirect, completes PKCE on callback, calls your `getAccessToken` for API auth. |
| **`CoinListServer`** (`createCoinListServer`) | Node-only: exchanges auth code for tokens, stores session, refreshes access tokens, logout. |
| **`CoinListProvider`** | Wraps the app and initializes the client (loads auth via `getAccessToken`). |
| **`useCoinList()`** | Access `coinlist` client + `isReady`. |
| **`CoinListSignInCard`** | Pre-built UI that calls `coinlist.startOAuth()`. |

**End-to-end flow** (same sequence as the SDK E2E test in `src/server/coinlist.server.e2e.spec.ts`):

1. User clicks sign-in → client stores PKCE `state` / `code_verifier` in **sessionStorage** and redirects to CoinList.
2. User authorizes → CoinList redirects to your **`redirectUri`** with `?code=…&state=…`.
3. On that page, the client runs **`completeOAuth()`** (validates state + reads code).
4. Your **backend** calls **`CoinListServer#completeOAuth(code, codeVerifier)`** → stores session (e.g. encrypted cookie).
5. For every API call / auth check, **`getAccessToken`** should resolve via **`CoinListServer#accessToken()`** (e.g. `GET /coinlist/access-token`).

`clientId`, `redirectUri`, and (on the server) `clientSecret` must match your CoinList OAuth app registration. **`redirectUri` on the client and server must be identical.**

---

## 1. Server: `CoinListServer`

Create a single server instance (e.g. one module used by API routes). You must implement **`SessionStore`** to persist the OAuth session (HTTP-only cookie, database, etc.).

```ts
// lib/coinlist-server.ts (runs on server only)
import { createCoinListServer, ClientId, ClientSecret, RedirectUri } from '@coinlist-co/react/server';

export const coinlistServer = createCoinListServer({
  clientId: ClientId(process.env.COINLIST_CLIENT_ID!),
  clientSecret: ClientSecret(process.env.COINLIST_CLIENT_SECRET!),
  redirectUri: RedirectUri(process.env.COINLIST_REDIRECT_URI!), // e.g. https://yourapp.com/auth/coinlist/callback
  sessionStore: yourSessionStore,
});
```

Exports: `createCoinListServer`, `CoinListServer`, `ServerConfig`, `SessionStore` from `@coinlist-co/react/server`.

---

## 2. API routes (Next.js)

### `POST /coinlist/oauth/complete`

Called from the browser after `completeOAuth()` succeeds. Body should include the **authorization code** and **code verifier** (as strings).

```ts
// app/api/coinlist/oauth/complete/route.ts
import { NextResponse } from 'next/server';
import type { CoinListServer } from '@coinlist-co/react/server';
import { coinlistServer } from '@/lib/coinlist-server';

export async function POST(req: Request) {
  const body = await req.json();
  const { code, codeVerifier } = body;
  if (typeof code !== 'string' || typeof codeVerifier !== 'string') {
    return NextResponse.json({ error: 'missing_fields' }, { status: 400 });
  }
  await coinlistServer.completeOAuth(
    code as Parameters<CoinListServer['completeOAuth']>[0],
    codeVerifier as Parameters<CoinListServer['completeOAuth']>[1]
  );
  return NextResponse.json({ ok: true });
}
```

`completeOAuth` exchanges the code with CoinList, then **`setSession`** on your store (e.g. sets the cookie).

### `GET /coinlist/access-token`

Used by the browser client’s **`getAccessToken`**. Must use the **logged-in user’s session** (cookie) and return JSON the SDK understands, or respond in a way your `getAccessToken` maps to `OAuthAccessToken | null`.

Typical pattern: the route calls **`await coinlistServer.accessToken()`**. If non-null, respond with JSON, e.g. `{ value: token.value, expiresAt: token.expiresAt.toISOString() }`; if logged out, use `401`, `204`, or an empty JSON body—consistent with your `getAccessToken` branch that returns **`null`**. Use **`credentials: 'include'`** on the client `fetch`.

```ts
// app/api/coinlist/access-token/route.ts
import { NextResponse } from 'next/server';
import { coinlistServer } from '@/lib/coinlist-server';

export async function GET() {
  const token = await coinlistServer.accessToken();
  if (token == null) {
    return new NextResponse(null, { status: 204 });
  }
  return NextResponse.json({
    value: token.value,
    expiresAt: token.expiresAt.toISOString(),
  });
}
```

---

## 3. Client: wrap with `CoinListProvider`

`getAccessToken` **must** eventually hit your backend (e.g. `GET /api/coinlist/access-token` or `/coinlist/access-token`) so the server can run **`CoinListServer#accessToken()`** (read session, refresh if needed).

```tsx
// app/providers.tsx (client component)
'use client';

import { CoinListProvider, ClientId, RedirectUri } from '@coinlist-co/react';

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <CoinListProvider
      config={{
        clientId: ClientId(process.env.NEXT_PUBLIC_COINLIST_CLIENT_ID!),
        redirectUri: RedirectUri(process.env.NEXT_PUBLIC_COINLIST_REDIRECT_URI!),
        getAccessToken: async () => {
          const res = await fetch('/api/coinlist/access-token', {
            credentials: 'include',
          });
          if (res.status === 401 || res.status === 204) return null;
          if (!res.ok) throw new Error('access-token failed');
          const data = await res.json();
          return {
            value: data.value,
            expiresAt: new Date(data.expiresAt),
          };
        },
      }}
    >
      {children}
    </CoinListProvider>
  );
}
```

Use **`useCoinList()`** for `isReady` and `coinlist`. Until `isReady` is true, auth state is still **`unknown`**.

---

## 4. Sign-in page: `CoinListSignInCard`

Render where you want users to start OAuth (must be under `CoinListProvider`).

```tsx
import { CoinListSignInCard } from '@coinlist-co/react/client/components';

export default function SignInPage() {
  return <CoinListSignInCard />;
}
```

This calls **`coinlist.startOAuth()`** (PKCE + redirect to CoinList).

---

## 5. OAuth callback page (`redirectUri`)

This route must match **`redirectUri`** exactly. On load, read query params, run **`completeOAuth()`**, then POST to your server.

```tsx
'use client';

import { useCoinList } from '@coinlist-co/react';
import { useSearchParams, useRouter } from 'next/navigation';
import { useEffect, useRef } from 'react';

export default function CoinListCallbackPage() {
  const { coinlist } = useCoinList();
  const searchParams = useSearchParams();
  const router = useRouter();
  const done = useRef(false);

  useEffect(() => {
    if (done.current) return;
    if (searchParams.get('error')) {
      router.replace('/sign-in?error=coinlist_denied');
      return;
    }
    if (!searchParams.get('code')) return;

    const res = coinlist.completeOAuth();
    if (res.type === 'error') {
      // e.g. 'missing_state' | 'invalid_state' | 'missing_code' | 'missing_code_verifier'
      router.replace('/sign-in?error=coinlist_oauth');
      return;
    }

    done.current = true;
    void (async () => {
      const complete = await fetch('/api/coinlist/oauth/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          code: res.code,
          codeVerifier: res.codeVerifier,
        }),
      });
      if (!complete.ok) {
        done.current = false;
        router.replace('/sign-in?error=coinlist_complete_failed');
        return;
      }
      await coinlist.init();
      router.replace('/');
    })();
  }, [coinlist, searchParams, router]);

  return <p>Completing sign-in…</p>;
}
```

**Notes:**

- **`completeOAuth()`** uses **`window.location.search`**. It must run on the **actual redirect URL** CoinList sent (same tab, full page load is fine).
- Avoid running the completion `POST` twice (e.g. React Strict Mode); a ref or idempotent backend helps.
- After the server sets the session cookie, call **`await coinlist.init()`** so the in-memory client picks up the new token (the provider only auto-inits once on mount).

---

## 6. Logout

- **Server:** `await coinlistServer.logout()` (revokes token, clears session).
- **Client:** `coinlist.logout()` only clears the client cache; pair it with a route that clears the session cookie / calls server logout.

---

## 7. Peer dependencies

- `react`, `react-dom` ≥ 18  

Tailwind CSS is **not required** as a peer dependency. Components ship with prebuilt styles (see [Styling](#styling)), so you can use this SDK with or without Tailwind in your app.
---

## 8. Package entry points

| Import path | Use |
|-------------|-----|
| `@coinlist-co/react` | `CoinListProvider`, `useCoinList`, `createCoinListClient`, types |
| `@coinlist-co/react/server` | `createCoinListServer`, `CoinListServer`, `SessionStore` |
| `@coinlist-co/react/client/components` | `CoinListSignInCard`, etc. |

---

## 9. Reference implementation

The canonical sequence (start OAuth → authorize → `completeOAuth` → `server.completeOAuth` → `server.accessToken` → `server.logout`) is exercised in **`src/server/coinlist.server.e2e.spec.ts`**. Align your Next.js routes and client callbacks with that flow when debugging.
